import ModelosPage from "./pages/ModelosPage";

export function IndexPage() {
  return (
    <main className="min-h-screen bg-base-300">
      {/* Todo! Organizar o conteúdo da página principal */}
      <ModelosPage />
    </main>
  );
}

export default IndexPage;
