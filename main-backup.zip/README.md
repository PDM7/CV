# Curriculum Vitae

<img width="621" height="903" alt="image" src="https://github.com/user-attachments/assets/f2301f47-d412-42a3-9e0e-6d3394e77cdf" />

<img width="1594" height="1808" alt="proto" src="https://github.com/user-attachments/assets/15d6f602-c46e-4ee6-aae8-1433d10100ed" />
